#Week 1 code for:  The Slides and the exercises at the end

# Slides

#need to load the package:

library(readxl)

#example_data <- read_excel("C:\\Users\\...\\filename.xlsx")

